* Template file usage

- The `platforms` folder shall contain the boostrap code for different platforms
- The `src` folder shall contain codes for the whole application both client and server, and common codes.