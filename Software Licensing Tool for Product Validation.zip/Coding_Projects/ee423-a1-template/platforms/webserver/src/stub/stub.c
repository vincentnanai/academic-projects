#include "stub.h"
#include <string.h>
#include <stdlib.h>


static const struct lws_http_mount root_mount = {
    .mountpoint = "/",
    .protocol = "httpService",
    .origin_protocol = LWSMPRO_CALLBACK,
    .mountpoint_len = 4,
};

static const struct lws_protocols* pprotocols[] = {
    PROTOCOL_HTTP,
    PROTOCOL_WS,
	LWS_PROTOCOL_LIST_TERM,
};

int main(int argc, const char** argv)
{

    TServer thisServer = {};
    
    if(ServerPrintHelp(argc, argv)) {
        return 0;
    }

    ServerInitByCmdPrompt(argc, argv, &thisServer);

    thisServer.creationInfo.pprotocols = pprotocols;
    thisServer.creationInfo.mounts = &root_mount;

    ServerPrintConfig(&thisServer);
    return ServerStart(&thisServer);
}
