#include "stub.h"

#include <assert.h>
#include <libwebsockets.h>
#include <stdio.h>
#include <string.h>

#define ContentType(rec_len, type_len, type, label) rec_len type_len type "\0" label "\0"
    static const char gMimeMap[] =
    ContentType("\x10","\x04","aac","audio/aac")
    ContentType("\x12","\x05","avif","image/avif")
    ContentType("\x16","\x04","avi","video/x-msvideo")
    ContentType("\x23","\x04","azw","application/vnd.amazon.ebook")
    ContentType("\x1F","\x04","bin","application/octet-stream")
    ContentType("\x10","\x04","bmp","image/bmp")
    ContentType("\x18","\x03","bz","application/x-bzip")
    ContentType("\x1A","\x04","bz2","application/x-bzip2")
    ContentType("\x18","\x04","cda","application/x-cdf")
    ContentType("\x18","\x04","csh","application/x-csh")
    ContentType("\x0F","\x04","css","text/css")
    ContentType("\x0F","\x04","csv","text/csv")
    ContentType("\x24","\x04","eot","application/vnd.ms-fontobject")
    ContentType("\x1C","\x05","epub","application/epub+zip")
    ContentType("\x16","\x03","gz","application/gzip")
    ContentType("\x10","\x04","gif","image/gif")
    ContentType("\x10","\x04","htm","text/html")
    ContentType("\x11","\x05","html","text/html")
    ContentType("\x1F","\x04","ico","image/vnd.microsoft.icon")
    ContentType("\x14","\x04","ics","text/calendar")
    ContentType("\x12","\x05","jpeg","image/jpeg")
    ContentType("\x11","\x04","jpg","image/jpeg")
    ContentType("\x15","\x03","js","text/javascript")
    ContentType("\x18","\x05","json","application/json")
    ContentType("\x1D","\x07","jsonld","application/ld+json")
    ContentType("\x11","\x04","mid","audio/midi")
    ContentType("\x14","\x05","midi","audio/x-midi")
    ContentType("\x16","\x04","mjs","text/javascript")
    ContentType("\x11","\x04","mp3","audio/mpeg")
    ContentType("\x10","\x04","mp4","video/mp4")
    ContentType("\x12","\x05","mpeg","video/mpeg")
    ContentType("\x10","\x04","oga","audio/ogg")
    ContentType("\x10","\x04","ogv","video/ogg")
    ContentType("\x16","\x04","ogx","application/ogg")
    ContentType("\x12","\x05","opus","audio/opus")
    ContentType("\x0F","\x04","otf","font/otf")
    ContentType("\x10","\x04","png","image/png")
    ContentType("\x16","\x04","pdf","application/pdf")
    ContentType("\x16","\x04","rtf","application/rtf")
    ContentType("\x16","\x03","sh","application/x-sh")
    ContentType("\x14","\x04","svg","image/svg+xml")
    ContentType("\x11","\x04","tif","image/tiff")
    ContentType("\x12","\x05","tiff","image/tiff")
    ContentType("\x10","\x03","ts","video/mp2t")
    ContentType("\x0F","\x04","ttf","font/ttf")
    ContentType("\x11","\x04","txt","text/plain")
    ContentType("\x18","\x05","wasm","application/wasm")
    ContentType("\x10","\x04","wav","audio/wav")
    ContentType("\x12","\x05","weba","audio/webm")
    ContentType("\x12","\x05","webm","video/webm")
    ContentType("\x12","\x05","webp","image/webp")
    ContentType("\x11","\x05","woff","font/woff")
    ContentType("\x13","\x06","woff2","font/woff2")
    ContentType("\x12","\x05","3gpv","video/3gpp")
    ContentType("\x11","\x04","3gp","audio/3gpp")
    ContentType("\x13","\x05","3g2v","video/3gpp2")
    ContentType("\x12","\x04","3g2","audio/3gpp2");
#undef ContentType

#define APP_STATIC_FILE_FOLDER ".static"

/**
 * @brief Called to valiate if a uri meets security requirements
 * @param uri
 * @return non zero if the uri is not permitted
 */
static int isUriNotPermitted(char* uri)
{
    return strstr(uri, "..") != NULL;
}


static char* getFileExtension(char* filename)
{
    const char* dot = strrchr(filename, '.');
    if(!dot || dot == filename) {
        // No extension found
        return "";
    }

    return &dot[1]; // Return the extension excluding the dot
}

static char* getMimeByFilenameExt(char* fileName)
{
    char 
        *extName = getFileExtension(fileName),
        *end = (void*)&gMimeMap[sizeof(gMimeMap) - 1], 
        *result = "application/octet-stream";

    if(!extName || !extName[0]) {
        return result;
    }

    for(char* substr = (void*)&gMimeMap[2]; *substr && substr < end; substr += substr[-2]) {
        if(strcmp(extName, substr))
            continue;
        result = (void*)&substr[substr[-1]];
        break;
    }
    return result;
}

static int initHttpSession(THttpSession *pss, char* requested_uri)
{
    char filepath[256];
    TServer *server = lws_context_user(pss->context);
    // compute the file path to be read
    if(!strcmp(requested_uri,"/"))
        requested_uri = "/index.html";

    // check if it is a source map request
    if(!strcmp(getFileExtension(requested_uri), "c") && server->srcMapRootPath[0])
    {
      snprintf(filepath, sizeof(filepath), "%s%s",server->srcMapRootPath,requested_uri);
    } else {
      snprintf(filepath, sizeof(filepath), APP_STATIC_FILE_FOLDER "%s", requested_uri);
    }
     
    pss->filePtr = fopen(filepath, "rb");
    if (pss->filePtr == NULL) {
        lwsl_notice("Can't open '%s'",filepath);
        return 1;
    }
    
    lwsl_notice("Serving '%s' " ,filepath);
    
    // computer file size
    fseek(pss->filePtr, 0L, SEEK_END);
    pss->fileSize = ftell(pss->filePtr);
    fseek(pss->filePtr, 0L, SEEK_SET);
    pss->bytesRead = 0;
    
    // compute the mime via file-name extension
    pss->mime = getMimeByFilenameExt(requested_uri);
    return 0;
}

static int finaliseHttpSession(THttpSession *pss)
{
    fclose(pss->filePtr);
}

int httpServiceCallback(struct lws* wsi, enum lws_callback_reasons reason, void* user, void* in, size_t len)
{
    char* requested_uri = (char*)in;
    THttpSession *pss = user;
    
    // a buffer for both http header parts and body data
    uint8_t 
        buf[LWS_PRE + APP_TX_BUFFER_SIZE], 
        *start = &buf[LWS_PRE], 
        *p = start,
        *end = &buf[sizeof(buf) - 1];
    
    switch(reason) {
    case LWS_CALLBACK_HTTP: 
        {
            pss->context = lws_get_context(wsi);
            
            // Ensure the requested URI doesn't contain any hacking attacks
            if(isUriNotPermitted(requested_uri)) {
                lws_return_http_status(wsi, HTTP_STATUS_FORBIDDEN, NULL);
                break;
            }
            
            if(initHttpSession(pss, requested_uri))
            {
                lws_return_http_status(wsi, HTTP_STATUS_NOT_FOUND, NULL);
            }
            
            // generate the http header part
            if (lws_add_http_common_headers(wsi, HTTP_STATUS_OK, pss->mime, pss->fileSize, &p, end)
            || lws_finalize_write_http_header(wsi, start, &p, end))
                goto Error;
            
            lws_callback_on_writable(wsi);
        }
        return 0;
    case LWS_CALLBACK_HTTP_WRITEABLE:
        {
            size_t readAmount = pss->fileSize - pss->bytesRead;
            if (readAmount >= APP_TX_BUFFER_SIZE)
            {
                readAmount = APP_TX_BUFFER_SIZE;
            }
            
            pss->bytesRead += fread(start, sizeof(*buf), readAmount, pss->filePtr);
            int isLastBlock = (readAmount != APP_TX_BUFFER_SIZE);
            enum lws_write_protocol wrtState = isLastBlock ? LWS_WRITE_HTTP_FINAL : LWS_WRITE_HTTP;
         
            if (lws_write(wsi, (uint8_t *)start,  readAmount, wrtState) != readAmount)
            {
                goto Error;
            }
            
            if(isLastBlock)
            {
                finaliseHttpSession(pss);
                if (lws_http_transaction_completed(wsi))
                {
                    return -1;
                }
            } else {
                lws_callback_on_writable(wsi);
            }
            return 0;
        }
    default:
        break;
    }

    return lws_callback_http_dummy(wsi, reason, user, in, len);

Error:
    finaliseHttpSession(pss);
    return 1;
}