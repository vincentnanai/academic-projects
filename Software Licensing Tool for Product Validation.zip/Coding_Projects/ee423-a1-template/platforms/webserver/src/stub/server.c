#include "stub.h"

static const char gAppTitle[] = "Wantok HTTP/WS API Server, Version 01.01.00 \n"
                                "Copyright (c) PNG University of Technology, Inc. 2020-2024\n"
                                "Written by Mr David Chen, School of Electrical and Communication Engineering\n";

int ServerPrintHelp(int argc, const char** argv)
{
    const char* p = lws_cmdline_option(argc, argv, "-help");

    if(!p)
        p = lws_cmdline_option(argc, argv, "-h");
    if(!p)
        p = lws_cmdline_option(argc, argv, "?");

    if(!p)
        return 0;

    lwsl_user(gAppTitle);
    lwsl_user("\n"
              "Options:\n"
              " -help (or -h, \"?\") prints this message\n"
              " -port(n) sets the port number to be used by the server.\n"
              "  E.g. \"-port 5000\" will set the server to listen to port\n"
              "  5000. Default value is 8080.\n"
              " -d(n) sets the logs level where n is the bit value\n"
              " -src_map_rootpath set the root path os src files for debugging wasm files\n"
              );
              

    return 1;
}

int ServerInitByCmdPrompt(int argc, const char** argv, TServer* server)
{
    const char* p = NULL;

    if(!server)
        return -1;
    
    struct lws_context_creation_info* info = &server->creationInfo;
    
    /*configurable settings*/
#define cmd(v, T, F) ((typeof(T))(((p = lws_cmdline_option(argc, argv, v)) && *p) ? (T) : (F)))
    /*set port number  */ info->port = cmd("-port", atoi(p), 8080);
    /*set vhost name   */ info->vhost_name = cmd("-vhost_name", p, "localhost");
    /*set dbg src path */ server->srcMapRootPath = cmd("-src_map_rootpath", p, "");
    /*set logging level*/ lws_set_log_level(cmd("-d", atoi(p), LLL_USER | LLL_ERR | LLL_WARN | LLL_NOTICE), NULL);
#undef cmd
    
    /*hard settings*/
    info->options =
        LWS_SERVER_OPTION_EXPLICIT_VHOSTS; 
        //| LWS_SERVER_OPTION_HTTP_HEADERS_SECURITY_BEST_PRACTICES_ENFORCE;
    
    info->user = server;
    
    return 0;
}

int ServerPrintConfig(TServer* server)
{
    if(!server)
        return -1;

    struct lws_context_creation_info* info = &server->creationInfo;
    printf(gAppTitle);
    printf("url: http://%s:%ld\n", info->vhost_name, info->port);
    if(server->srcMapRootPath[0])
      printf(" srcMapRootPath: %s\n", server->srcMapRootPath);
    return 0;
}

static int interrupted;
static void sigint_handler(int sig) { interrupted = 1; }
int ServerStart(TServer* server)
{
    if(!server)
        return -1;

    struct lws_context_creation_info* info = &server->creationInfo;
    int retv = 0;
    server->context = lws_create_context(info);
    if(!server->context) {
        lwsl_err("lws init failed\n");
        return -1;
    }

    if(!lws_create_vhost(server->context, info)) {
        lwsl_err("Failed to create tls vhost\n");
        lws_context_destroy(server->context);
        return -1;
    }
    
    signal(SIGINT, sigint_handler);

    while(retv >= 0 && !interrupted)
        retv = lws_service(server->context, 0);

    return 0;
}