#pragma once

#include "../wsService.h"
#include "../../../../src/msgStruct.h"

#include <signal.h>
#include <string.h>
#include <time.h>
#include <stdio.h>



#define APP_TX_BUFFER_SIZE 256

typedef struct {
    struct lws_context* context;
    FILE *filePtr;
    char *mime;
    size_t fileSize;
    size_t bytesRead;
} THttpSession;

typedef struct {
    struct lws_context_creation_info creationInfo;
    struct lws_context* context;
    const char *srcMapRootPath;
} TServer;

#define PROTOCOL_WS                                                          \
    &(struct lws_protocols){                                                                        \
        "wsService", wss_fnWebsocketCallback, sizeof(wss_TSession), sizeof(ws_TMsg), 0, NULL, 0 \
    }

#define PROTOCOL_HTTP                                                            \
    &(struct lws_protocols){                                                    \
        "httpService", httpServiceCallback, sizeof(THttpSession), APP_TX_BUFFER_SIZE, 0, NULL, 0 \
    }


/**
 * Service Callbacks Configs
 */
extern int httpServiceCallback(struct lws* wsi, enum lws_callback_reasons reason, void* user, void* in, size_t len);

/**
 * Server functions
 */
extern int ServerInitByCmdPrompt(int argc, const char** argv, TServer*);
extern int ServerPrintConfig(TServer*);
extern int ServerPrintHelp(int argc, const char** argv);
extern int ServerStart(TServer*);