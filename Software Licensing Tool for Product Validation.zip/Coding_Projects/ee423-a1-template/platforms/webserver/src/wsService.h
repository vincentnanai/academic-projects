#pragma once
#include <libwebsockets.h>

/**
 * TWsSession is used for holding data 
 * per client-server connection
 */
typedef struct {
    char userName[32];
} wss_TSession;

/**
 * TWsContext This structure contains the fields
 * for the Websocket service. hence it is only
 * created once as per server process.
 */
typedef struct {
  struct lws_context *context;
	struct lws_vhost *vhost;
	int *interrupted;
	int *options;
} wss_TContext;


extern int wss_fnWebsocketCallback(struct lws* wsi, enum lws_callback_reasons reason, void* user, void* in, size_t len);