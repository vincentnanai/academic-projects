#include "stub/stub.h"
#include <bitproto/lib_protocol.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <string.h>
#include <stdio.h>

#define MAX_MESSAGE_SIZE 128
#define SYMMETRIC_KEY "your-symmetric-key-here" // Replace with your actual symmetric key

// Helper functions
static char* base64_encode(const unsigned char* data, size_t len) {
    BIO *bio, *b64;
    BUF_MEM *bptr;
    
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);
    
    BIO_write(bio, data, len);
    BIO_flush(bio);
    
    BIO_get_mem_ptr(bio, &bptr);
    char *buf = malloc(bptr->length);
    memcpy(buf, bptr->data, bptr->length - 1);
    buf[bptr->length - 1] = '\0';
    
    BIO_free_all(bio);
    
    return buf;
}

static int base64_decode(const char* b64message, unsigned char** buffer, size_t* length) {
    BIO *bio, *b64;
    int decodeLen = strlen(b64message);
    int len;
    
    *buffer = (unsigned char *)malloc(decodeLen);
    
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new_mem_buf(b64message, -1);
    bio = BIO_push(b64, bio);
    
    len = BIO_read(bio, *buffer, decodeLen);
    BIO_free_all(bio);
    
    *length = len;
    
    return (len > 0);
}

static void encrypt_message(const char *plaintext, unsigned char *ciphertext, size_t *ciphertext_len) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;
    
    EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char*)SYMMETRIC_KEY, NULL);
    EVP_EncryptUpdate(ctx, ciphertext, &len, (unsigned char*)plaintext, strlen(plaintext));
    *ciphertext_len = len;
    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    *ciphertext_len += len;
    
    EVP_CIPHER_CTX_free(ctx);
}

static int decrypt_message(const unsigned char *ciphertext, size_t ciphertext_len, char *plaintext) {
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    int len;
    
    EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, (unsigned char*)SYMMETRIC_KEY, NULL);
    EVP_DecryptUpdate(ctx, (unsigned char*)plaintext, &len, ciphertext, ciphertext_len);
    int plaintext_len = len;
    EVP_DecryptFinal_ex(ctx, (unsigned char*)plaintext + len, &len);
    plaintext_len += len;
    plaintext[plaintext_len] = '\0';
    
    EVP_CIPHER_CTX_free(ctx);
    
    return plaintext_len;
}

int wss_fnWebsocketCallback(struct lws *wsi, enum lws_callback_reasons reason,
                            void *user, void *in, size_t len) {
    wss_TSession *session;
    wss_TContext *ctxt = lws_protocol_vh_priv_get(lws_get_vhost(wsi), lws_get_protocol(wsi));

    int retv = 0;
    switch (reason) {

    case LWS_CALLBACK_PROTOCOL_INIT:
        ctxt = lws_protocol_vh_priv_zalloc(
            lws_get_vhost(wsi), lws_get_protocol(wsi), sizeof(wss_TContext));

        if (!ctxt)
            return -1;

        break;

    case LWS_CALLBACK_ESTABLISHED:
        // Initialize your session-specific data here
        session = user;
        // Initialize your data
        // data->some_field = initial_value;

        break;

    case LWS_CALLBACK_RECEIVE: {
        const char *incoming_message = (const char *)in;

        // Example message handling
        if (strstr(incoming_message, "LGR") == incoming_message) {
            // Encrypt and encode message
            unsigned char encrypted_message[MAX_MESSAGE_SIZE];
            size_t encrypted_message_len;
            encrypt_message(incoming_message + 4, encrypted_message, &encrypted_message_len); // Skip "LGR"
            char *encoded_message = base64_encode(encrypted_message, encrypted_message_len);
            
            // Send response with LGA
            size_t message_len = strlen(encoded_message);
            unsigned char buffer[LWS_PRE + MAX_MESSAGE_SIZE];
            memcpy(&buffer[LWS_PRE], encoded_message, message_len);
            lws_write(wsi, &buffer[LWS_PRE], message_len, LWS_WRITE_TEXT);
            free(encoded_message);
        } else if (strstr(incoming_message, "LVR") == incoming_message) {
            // Decode and decrypt message
            unsigned char *decoded_message;
            size_t decoded_message_len;
            if (base64_decode(incoming_message + 4, &decoded_message, &decoded_message_len)) { // Skip "LVR"
                char decrypted_message[MAX_MESSAGE_SIZE];
                if (decrypt_message(decoded_message, decoded_message_len, decrypted_message)) {
                    // Check if the license is valid (not expired)
                    // For example, you could have a function to check the license validity
                    bool is_license_valid = true; // Replace with actual validity check
                    
                    // Send response
                    const char *response = is_license_valid ? "LVR_OK" : "LVR_ERR";
                    size_t message_len = strlen(response);
                    unsigned char buffer[LWS_PRE + MAX_MESSAGE_SIZE];
                    memcpy(&buffer[LWS_PRE], response, message_len);
                    lws_write(wsi, &buffer[LWS_PRE], message_len, LWS_WRITE_TEXT);
                } else {
                    // Send LVR_ERR if decryption fails
                    const char *response = "LVR_ERR";
                    size_t message_len = strlen(response);
                    unsigned char buffer[LWS_PRE + MAX_MESSAGE_SIZE];
                    memcpy(&buffer[LWS_PRE], response, message_len);
                    lws_write(wsi, &buffer[LWS_PRE], message_len, LWS_WRITE_TEXT);
                }
                free(decoded_message);
            }
        }

        break;
    }

    case LWS_CALLBACK_CLOSED:
        break;

    default:
        retv = lws_callback_http_dummy(wsi, reason, user, in, len);
        break;
    }

    return retv;
}
