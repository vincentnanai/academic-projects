
#pragma once
#include <stdint.h>

typedef enum {
	wmd_ECall_WarnCameraSetupInProgress = 2,
	wmd_ECall_WarnInitInProgress = 1,
	wmd_ECall_Success = 0,
	wmd_ECall_ErrSettingInvalid = -1,
	wmd_ECall_ErrInvalidTextureTarget = -2,
	wmd_ECall_ErrGLContextNotReady = -3,
	wmd_ECall_ErrNotSupported = -4,
	wmd_ECall_ErrInvalidDevId = -5,
	wmd_ECall_ErrInvalidTargetId = -6,
} wmd_ECall;

typedef enum {
	wmd_EStatus_Ready = 0,
	wmd_EStatus_Initialising = 1,
	wmd_EStatus_PlatformNotSupported = 2,
} wmd_EStatus;


typedef enum {
	wmd_EDeviceType_Undefined = 0,
	wmd_EDeviceType_AudioInput = 1,
	wmd_EDeviceType_AudioOutput = 2,
	wmd_EDeviceType_VideoInput = 3,
} wmd_EDeviceType;

typedef enum {
  wmd_ETargetCap_VideoUnknown = 0,
	wmd_ETargetCap_VideoHeightInt = 1,
  wmd_ETargetCap_VideoWidthInt = 2,
  wmd_ETargetCap_VideoFrameRateFloat = 3,
  wmd_ETargetCap_VideoAspectRatioFloat = 4,
  wmd_ETargetCap_AudioUnknown = 256,
} wmd_ETargetCap;

wmd_EStatus wmd_status();
int wmd_getDeviceCount();
wmd_EDeviceType wmd_getDeviceType(int devId);
wmd_ECall wmd_getDeviceLabel(int devId, int* strBuffSize, char* out_strBuff);

double wmd_getTargetCapsFloat64(int devId, wmd_ETargetCap cap);
int64_t wmd_getTargetCapsInt64(int devId, wmd_ETargetCap cap);
int wmd_isTargetActive(int targetId);

int wmd_createTarget();
int wmd_getDefaultDeviceIdByType(wmd_EDeviceType devType);
wmd_ECall wmd_bindTargetToDevice(int targetID, int devID);
wmd_ECall wmd_drawTargetToTexture(int targetID, int glTextureId);

