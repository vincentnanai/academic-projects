
var libdef = {

  // create the auxiliary methods and initialisation needed for
  // the library here.
  //	* note: the '$' ident prefix is to indicate this method
  // is "private" to this library. Hence calling this method
  // NEED-NOT require the "_" (underscore) prefix.
  $lib_wmdjs__postset : 'lib_wmdjs()',
  $lib_wmdjs__deps :
      [ '$GL' ], // Need to translated any GL objects into WebGl Native Objects
  $lib_wmdjs : async function() {
    // create invisible container for the camera inputs
    var _container = document.createElement('div');
    _container.style.display = 'none';
    document.body.appendChild(_container);

    // contains private globals for the module.
    var _globals = {
      isReady : false,
      hasTryGainPermission : false,
      devices : null,
      deviceDefaultIds : {videoInDevId : null, audioInDevId : null},

      targetFnValidate : function(aTargetId) {
        var lib = this;
        var targetObj = lib.targets[aTargetId];
        if (targetObj === undefined)
          return [ lib.cEnum.wmd_ECall_ErrInvalidTargetId, null ];

        if (targetObj.isDirty) {
          targetObj.unDirtify();
          navigator.mediaDevices.getUserMedia(targetObj.getStreamConfig())
              .then((stream) => { targetObj.setStreamSrc(stream); });
        }

        if (!targetObj.hasStreamSrc)
          return [ lib.cEnum.wmd_ECall_WarnCameraSetupInProgress, null ];

        return [ lib.cEnum.wmd_ECall_Success, targetObj ]
      },

      targetClass : function() {
        var camera = document.createElement('video');
        var isVideoReady = false;
        var me = this;
        _container.appendChild(camera);

        camera.addEventListener("playing", function() { isVideoReady = true; },
                                true);

        camera.addEventListener("ended", function() {
          camera.currentTime = 0;
          camera.play();
        }, true);

        Object.defineProperty(me, 'stream',
                              {get : function() { return camera.srcObject; }});

        Object.defineProperty(me, 'camera',
                              {get : function() { return camera; }});

        Object.defineProperty(me, 'isVideoReady',
                              {get : function() { return isVideoReady; }});

        Object.defineProperty(me, 'isDirty', {
          get : function() {
            return me.config.videoInDevId != me.newConfig.videoInDevId ||
                   me.config.audioInDevId != me.newConfig.audioInDevId;
          }
        });

        Object.defineProperty(me, 'hasStreamSrc',
                              {get : function() { return me.stream != null; }});

        Object.defineProperty(me, 'audioInDevId', {
          get : function() { return me.newConfig.audioInDevId; },
          set : function(
              aAudioInDevId) { me.newConfig.audioInDevId = aAudioInDevId; }
        });

        Object.defineProperty(me, 'videoInDevId', {
          get : function() { return me.newConfig.videoInDevId; },
          set : function(
              aVideoInDevId) { me.newConfig.videoInDevId = aVideoInDevId; }
        });

        me.unDirtify = function() {
          if (!me.isDirty)
            return;
          camera.pause();
          me.config.videoInDevId = me.newConfig.videoInDevId;
          me.config.audioInDevId = me.newConfig.audioInDevId;
          camera.srcObject = null;
        };

        me.getStreamConfig = function() {
          var config = {};

          if (me.config.videoInDevId !== null)
            config.video = {deviceId : me.config.videoInDevId};

          if (me.config.audioInDevId !== null)
            config.audio = {deviceId : me.config.audioInDevId};

          return config;
        };

        me.setStreamSrc = function(aStream) {
          camera.srcObject = aStream;
          camera.play();
        };
      },
      targets : [],
      GL : GL,
      cEnum : {
        // wmd_ECalls
        wmd_ECall_WarnCameraSetupInProgress : 2,
        wmd_ECall_WarnInitInProgress : 1,
        wmd_ECall_Success : 0,
        wmd_ECall_ErrSettingInvalid : -1,
        wmd_ECall_ErrInvalidTextureTarget : -2,
        wmd_ECall_ErrGLContextNotReady : -3,
        wmd_ECall_ErrNotSupported : -4,
        wmd_ECall_ErrInvalidDevId : -5,
        wmd_ECall_ErrInvalidTargetId : -6,

        // wmd_EDeviceType
        wmd_EDeviceType_Undefined : 0,
        wmd_EDeviceType_AudioInput : 1,
        wmd_EDeviceType_AudioOutput : 2,
        wmd_EDeviceType_VideoInput : 3,

        // wmd_EStatus
        wmd_EStatus_Ready : 0,
        wmd_EStatus_Initialising : 1,
        wmd_EStatus_PlatformNotSupported : 2,

        // wmd_ETargetCap
        wmd_ETargetCap_VideoUnknown : 0,
        wmd_ETargetCap_VideoHeightInt : 1,
        wmd_ETargetCap_VideoWidthInt : 2,
        wmd_ETargetCap_VideoFrameRateFloat : 3,
        wmd_ETargetCap_VideoAspectRatioFloat : 4,
        wmd_ETargetCap_AudioUnknown : 256,
      }
    };

    // define the default value default values
    var proto = _globals.targetClass.prototype;
    proto.config = {videoInDevId : null, audioInDevId : null};
    proto.newConfig = {videoInDevId : null, audioInDevId : null};

    // query all the devices available from the browser
    // platform.
    if (!navigator.mediaDevices?.enumerateDevices) {
      console.error("enumerateDevices() not supported.");
    } else {
      // List cameras and microphones.
      _globals.fnInitDevices = function(defaultStream) {
        var audioTracks = defaultStream.getAudioTracks();
        var videoTracks = defaultStream.getVideoTracks();
        var audioLabel = null;
        var videoLabel = null;

        if (audioTracks.length) {
          audioLabel = audioTracks[0].label;
        }

        if (videoTracks.length) {
          videoLabel = videoTracks[0].label;
        }

        _globals.hasTryGainPermission = true;
        navigator.mediaDevices.enumerateDevices()
            .then((devices) => {
              _globals.devices = devices;
              _globals.isReady = true;
              devices.forEach((device, idx) => {
                if (audioLabel == device.label) {
                  _globals.deviceDefaultIds.audioInDevId = idx;
                  proto.newConfig.audioInDevId = device.id;
                } else if (videoLabel == device.label) {
                  _globals.deviceDefaultIds.videoInDevId = idx;
                  proto.newConfig.videoInDevId = device.id;
                }
              });
            })
            .catch((err) => { console.error(`${err.name}: ${err.message}`); });
      };
    }
    lib_wmdjs = function() { return _globals; };
  },

  wmd_status__deps : [ '$lib_wmdjs' ],
  wmd_status : function() {
    var lib = lib_wmdjs();
      
    if (!lib.fnInitDevices)
      return lib.cEnum.wmd_EStatus_PlatformNotSupported;

    if (!lib.hasTryGainPermission) {
      navigator.mediaDevices.getUserMedia({audio : true, video : true})
          .then(lib.fnInitDevices)
          .catch((err)=>{
            lib.fnInitDevices = null;
            console.error(`${err.name}:${err.message}`);
            });
      lib.hasTryGainPermission = true;
    }

    if (!lib.isReady)
      return lib.cEnum.wmd_EStatus_Initialising;

    return lib.cEnum.wmd_EStatus_Ready;
  },

  wmd_getDeviceCount__deps : [ '$lib_wmdjs' ],
  wmd_getDeviceCount : function() {
    var lib = lib_wmdjs();
    if (!lib.isReady || !lib.hasTryGainPermission)
      return 0;
    return lib_wmdjs().devices.length;
  },

  wmd_getDeviceType__deps : [ '$lib_wmdjs' ],
  wmd_getDeviceType : function(devId) {
    var lib = lib_wmdjs();
    if (!lib.isReady || !lib.hasTryGainPermission || devId < 0 ||
        devId >= lib.devices.length)
      return lib.cEnum.wmd_EDeviceType_Undefined;

    switch (lib.devices[devId].kind) {
    case "audioinput":
      return lib.cEnum.wmd_EDeviceType_AudioInput; // wmd_EDeviceType_AudioInput
    case "audiooutput":
      return lib.cEnum
          .wmd_EDeviceType_AudioOutput; // wmd_EDeviceType_Audiooutput
    case "videoinput":
      return lib.cEnum.wmd_EDeviceType_VideoInput; // wmd_EDeviceType_VideoInput
    }

    return lib.cEnum.wmd_EDeviceType_Undefined;
  },

  wmd_getDeviceLabel__deps : [ '$lib_wmdjs', '$stringToUTF8' ],
  wmd_getDeviceLabel : function(devId, byteBuffLenPtr, byteBuffPtr) {
    var devices = lib_wmdjs().devices;
    var lib = lib_wmdjs();

    if (!lib.isReady || !lib.hasTryGainPermission || devId < 0 ||
        devId >= lib.devices.length)
      return lib.cEnum.wmd_ECall_ErrNotSupported;

    var vIntPtr = null;
    var vStrPtr = null;

    if (vIntPtr === 0)
      return lib.cEnum.wmd_ECall_ErrNotSupported;
    vIntPtr = new Int32Array(Module.HEAPU8.buffer, byteBuffLenPtr, 1);

    var jsString = devices[devId].label;
    if (byteBuffPtr === 0) {
      vIntPtr[0] = jsString.length + 1;
      return lib.cEnum.wmd_ECall_Success;
    }

    Module.stringToUTF8(jsString, byteBuffPtr, vIntPtr[0]);
    return lib.cEnum.wmd_ECall_Success; // wmd_ECall_Success
  },

  wmd_getDefaultDeviceIdByType__deps : [ '$lib_wmdjs' ],
  wmd_getDefaultDeviceIdByType : function(devTypeEnum) {
    var lib = lib_wmdjs();
    if (!lib.isReady || !lib.hasTryGainPermission)
      return lib.cEnum.wmd_ECall_ErrNotSupported;

    switch (devTypeEnum) {
    case lib.cEnum.wmd_EDeviceType_AudioInput:
      return lib.deviceDefaultIds.audioInDevId;
    case lib.cEnum.wmd_EDeviceType_VideoInput:
      return lib.deviceDefaultIds.videoInDevId;
    }
    return lib.cEnum.wmd_ECall_ErrSettingInvalid;
  },

  wmd_createTarget__deps : [ '$lib_wmdjs' ],
  wmd_createTarget : function() {
    var lib = lib_wmdjs();
    if (!lib.isReady || !lib.hasTryGainPermission)
      return lib.cEnum.wmd_ECall_ErrNotSupported;

    // create visible video tag to capture video.
    let newTarget = new lib.targetClass();

    lib.targets.push(newTarget);
    return lib.targets.length - 1;
  },

  wmd_bindTargetToDevice__deps : [ '$lib_wmdjs', 'wmd_getDeviceType' ],
  wmd_bindTargetToDevice : function(aTargetId, aDevId) {
    var lib = lib_wmdjs();
    if (!lib.isReady || !lib.hasTryGainPermission)
      return lib.cEnum.wmd_ECall_ErrNotSupported;

    var devObj = lib.devices[aDevId];
    if (devObj === undefined)
      return lib.cEnum.wmd_ECall_ErrInvalidDevId;

    var targetObj = lib.targets[aTargetId];
    if (targetObj === undefined)
      return lib.cEnum.wmd_ECall_ErrInvalidTargetId;

    switch (_wmd_getDeviceType(aDevId)) {
    case lib.cEnum.wmd_EDeviceType_AudioInput:
      targetObj.audioInDevId = lib.devices[aDevId].deviceId;
      break;
    case lib.cEnum.wmd_EDeviceType_VideoInput:
      targetObj.videoInDevId = lib.devices[aDevId].deviceId;
      break;
    case lib.cEnum.wmd_EDeviceType_AudioOutput:
      break;
    default:
      return lib.cEnum.wmd_ECall_ErrSettingInvalid;
    }
  },

  wmd_drawTargetToTexture__deps : [ '$lib_wmdjs', 'glIsTexture' ],
  wmd_drawTargetToTexture : function(aTargetId, aGLTexId) {
    var lib = lib_wmdjs();
    if (!lib.isReady || !lib.hasTryGainPermission)
      return lib.cEnum.wmd_ECall_ErrNotSupported;

    if (!_glIsTexture(aGLTexId))
      return lib.cEnum.wmd_ECall_ErrInvalidTextureTarget;

    const [result, targetObj] = lib.targetFnValidate(aTargetId);

    if (result)
      return result;

    // Do webgl functions calls via the webGL_ctx object.
    var gl = lib.GL.currentContext?.GLctx;
    if (gl === null || !targetObj.isVideoReady) {
      return lib.cEnum.wmd_ECall_ErrGLContextNotReady;
    }

    // Setup textures
    const originalTexture = gl.getParameter(gl.TEXTURE_BINDING_2D);
    const targetTexture = lib.GL.textures[aGLTexId];

    // Perform the rendering to target
    gl.bindTexture(gl.TEXTURE_2D, targetTexture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE,
                  targetObj.camera);

    // Restore the original texture binding
    gl.bindTexture(gl.TEXTURE_2D, originalTexture);
    return lib.cEnum.wmd_ECall_Success;
  },

  wmd_getTargetCapsInt64__deps : [ '$lib_wmdjs' ],
  wmd_getTargetCapsInt64 : function(aTargetId, capEnum) {
    var lib = lib_wmdjs();
    const [result, targetObj] = lib.targetFnValidate(aTargetId);

    if (result)
      return 0;

    if (capEnum < lib.cEnum.wmd_ETargetCap_AudioUnknown) // video stream
    {
      var videoTracks = targetObj.stream.getVideoTracks();
      if (!videoTracks.length)
        return 0;

      var capList = videoTracks[0].getSettings();
      switch (capEnum) {
      case lib.cEnum.wmd_ETargetCap_VideoHeightInt:
        return capList.height;
      case lib.cEnum.wmd_ETargetCap_VideoWidthInt:
        return capList.width;
      }
    }
    return 0;
  },

  wmd_getTargetCapsFloat64__deps : [ '$lib_wmdjs' ],
  wmd_getTargetCapsFloat64(aTargetId, capEnum) {
    var lib = lib_wmdjs();
    const [result, targetObj] = lib.targetFnValidate(aTargetId);

    if (result)
      return 0;

    if (capEnum < lib.cEnum.wmd_ETargetCap_AudioUnknown) // video stream
    {
      var videoTracks = targetObj.stream.getVideoTracks();
      if (!videoTracks.length)
        return 0;

      var capList = videoTracks[0].getSettings();
      switch (capEnum) {
      case lib.cEnum.wmd_ETargetCap_VideoFrameRateFloat:
        return capList.frameRate;
      case lib.cEnum.wmd_ETargetCap_VideoAspectRatioFloat:
        return capList.aspectRatio;
      }
    }
    return 0;
  },

  wmd_isTargetActive__deps : [ '$lib_wmdjs' ],
  wmd_isTargetActive : function(aTargetId) {
    var lib = lib_wmdjs();
    const [result, targetObj] = lib.targetFnValidate(aTargetId);
    return targetObj !== null;
  }
};

addToLibrary(libdef);