//CLient Code

#include "app.h"
#include <emscripten/console.h>
#include <libwmdjs.h>
#include <raylib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define RAYGUI_IMPLEMENTATION
#include <raygui.h>

typedef struct {
    sys_TApiWebSocket *apiWs;
    char productName[101]; // Max 100 characters + null terminator
    int expiryDayIndex;
    int expiryMonthIndex;
    int expiryYearIndex;
    char encodedLicense[256];
    char statusMessage[256];
    int currentTab;
    char validationLicense[256]; // For entering the base64 encoded license
    char validatedProductName[101]; // For displaying the product name
    char validatedExpiryDate[30]; // For displaying the expiry date
} spa_TUserData;

// Function to encode data to Base64
char *base64_encode(const unsigned char *data, size_t input_length) {
    const char *base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    size_t output_length = 4 * ((input_length + 2) / 3);
    char *encoded_data = (char *)malloc(output_length + 1);
    
    if (!encoded_data) return NULL;

    for (size_t i = 0, j = 0; i < input_length;) {
        unsigned char octet_a = i < input_length ? data[i++] : 0;
        unsigned char octet_b = i < input_length ? data[i++] : 0;
        unsigned char octet_c = i < input_length ? data[i++] : 0;

        unsigned char triple[3] = {octet_a, octet_b, octet_c};
        encoded_data[j++] = base64_chars[(triple[0] >> 2) & 0x3F];
        encoded_data[j++] = base64_chars[((triple[0] & 0x03) << 4) | (triple[1] >> 4)];
        encoded_data[j++] = base64_chars[((triple[1] & 0x0F) << 2) | (triple[2] >> 6) & 0x03];
        encoded_data[j++] = base64_chars[triple[2] & 0x3F];
    }
    // Add padding characters
    for (size_t i = output_length - 1; (i >= output_length - 2) && (i < output_length); i--) {
        encoded_data[i] = '=';
    }
    encoded_data[output_length] = '\0';
    return encoded_data;
}

static void app_fnWsOnMsg(bool isError, ws_TMsg *msg, void *usrData) {
    spa_TUserData *appData = usrData;
    if (isError) {
        snprintf(appData->statusMessage, sizeof(appData->statusMessage), "Error receiving message.");
        return;
    }
    snprintf(appData->encodedLicense, sizeof(appData->encodedLicense), "%s", msg->bytes);
    snprintf(appData->statusMessage, sizeof(appData->statusMessage), "License Generated!");
}

static void app_fnDrawGui(spa_TUserData *appData) {
    // Navigation Tabs
    const char *tabs[] = {"Generate", "Validate"};
    GuiTabBar((Rectangle){10, 10, 300, 30}, tabs, 2, &appData->currentTab); // Pass address of currentTab

    if (appData->currentTab == 0) { // Generate Tab
        // License Settings Group
        GuiGroupBox((Rectangle){10, 50, 325, 250}, "License Settings");
        
        GuiLabel((Rectangle){20, 70, 200, 20}, "Product Name:");
        GuiTextBox((Rectangle){20, 90, 260, 30}, appData->productName, sizeof(appData->productName), true);

        // Expiry Date Dropdowns
        GuiLabel((Rectangle){20, 130, 200, 20}, "Expiry Date:");
        
        // Days Dropdown
        const char *daysOptions = "1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16;17;18;19;20;21;22;23;24;25;26;27;28;29;30;31";
        if (GuiDropdownBox((Rectangle){20, 150, 80, 30}, daysOptions, &appData->expiryDayIndex, false)) {}

        // Months Dropdown
        const char *monthsOptions = "Jan;Feb;Mar;Apr;May;Jun;Jul;Aug;Sep;Oct;Nov;Dec";
        if (GuiDropdownBox((Rectangle){110, 150, 80, 30}, monthsOptions, &appData->expiryMonthIndex, false)) {}

        // Years Dropdown
        const char *yearsOptions = "2023;2024;2025;2026;2027";
        if (GuiDropdownBox((Rectangle){200, 150, 80, 30}, yearsOptions, &appData->expiryYearIndex, false)) {}

        // Generate License Button
        if (GuiButton((Rectangle){20, 190, 100, 30}, "Generate License")) {
            if (strlen(appData->productName) == 0) {
                snprintf(appData->statusMessage, sizeof(appData->statusMessage), "Please enter a product name.");
            } else {
                char dataToEncode[256];
                snprintf(dataToEncode, sizeof(dataToEncode), "%s|%d-%d-%d", appData->productName, 
                         appData->expiryDayIndex + 1, appData->expiryMonthIndex + 1, 2023 + appData->expiryYearIndex);
                char *encoded = base64_encode((unsigned char *)dataToEncode, strlen(dataToEncode));
                if (encoded) {
                    snprintf(appData->encodedLicense, sizeof(appData->encodedLicense), "%s", encoded);
                    free(encoded);
                    snprintf(appData->statusMessage, sizeof(appData->statusMessage), "License ready to copy.");
                } else {
                    snprintf(appData->statusMessage, sizeof(appData->statusMessage), "Failed to encode license.");
                }
            }
        }

        // License Data Group
        GuiGroupBox((Rectangle){10, 310, 325, 150}, "License Data");
        
        // Display Encoded License
        GuiLabel((Rectangle){20, 330, 200, 20}, "Encoded License:");
        GuiTextBox((Rectangle){20, 350, 260, 30}, appData->encodedLicense, sizeof(appData->encodedLicense), false);

        // Copy License Button
        if (GuiButton((Rectangle){20, 390, 100, 30}, "Copy to Clipboard")) {
            char logMessage[256];
            snprintf(logMessage, sizeof(logMessage), "License copied to clipboard: %s", appData->encodedLicense);
            emscripten_console_log(logMessage); // Use a JavaScript function to copy to clipboard
            snprintf(appData->statusMessage, sizeof(appData->statusMessage), "License copied to clipboard.");
        }

        // Status Message
        GuiLabel((Rectangle){20, 430, 300, 20}, appData->statusMessage);
    } 
    else if (appData->currentTab == 1) { // Validate Tab
        // License Validation Group
        GuiGroupBox((Rectangle){10, 50, 325, 250}, "License Data");
        
        GuiLabel((Rectangle){20, 70, 200, 20}, "Enter License:");
        GuiTextBox((Rectangle){20, 90, 260, 30}, appData->validationLicense, sizeof(appData->validationLicense), true);

        // Button to Validate License
        if (GuiButton((Rectangle){20, 130, 120, 30}, "Validate License")) {
            // TODO: Add logic to send the license to the server for validation
            snprintf(appData->validatedProductName, sizeof(appData->validatedProductName), "Product Name: Example"); // Replace with actual response
            snprintf(appData->validatedExpiryDate, sizeof(appData->validatedExpiryDate), "Expiry Date: 2024-12-31"); // Replace with actual response
        }

        // Button to Paste from Clipboard
        if (GuiButton((Rectangle){160, 130, 120, 30}, "Paste from Clipboard")) {
            // TODO: Implement clipboard paste functionality
            snprintf(appData->validationLicense, sizeof(appData->validationLicense), "Pasted License Here"); // Replace with actual clipboard content
        }

        // Validation Results Group
        GuiGroupBox((Rectangle){10, 310, 325, 150}, "Is Valid!");
        
        // Display Product Name
        GuiLabel((Rectangle){20, 330, 200, 20}, "Product Name:");
        GuiTextBox((Rectangle){20, 350, 260, 30}, appData->validatedProductName, sizeof(appData->validatedProductName), false);

        // Display Expiry Date
        GuiLabel((Rectangle){20, 390, 200, 20}, "Expiry Date:");
        GuiTextBox((Rectangle){20, 410, 260, 30}, appData->validatedExpiryDate, sizeof(appData->validatedExpiryDate), false);
    }
}

void app_OnSetup(sys_TApiSetup *apiSetup) {
    static spa_TUserData appData;
    appData.apiWs = apiSetup->useWebSocket(apiSetup, app_fnWsOnMsg, NULL);
    appData.productName[0] = '\0'; // Initialize
    appData.encodedLicense[0] = '\0'; // Initialize
    appData.statusMessage[0] = '\0'; // Initialize
    appData.validationLicense[0] = '\0'; // Initialize for validation
    appData.validatedProductName[0] = '\0'; // Initialize for validation
    appData.validatedExpiryDate[0] = '\0'; // Initialize for validation
    appData.expiryDayIndex = 0; // Default values
    appData.expiryMonthIndex = 0; // Default values
    appData.expiryYearIndex = 0; // Default values
    appData.currentTab = 0; // Default to "Generate" tab
    apiSetup->setAppData(apiSetup, &appData);
    apiSetup->setAppWindowTitle(apiSetup, "Software Licensing Tool");
}

void app_OnUpdate(sys_EStatus status, void *usrData) {
    spa_TUserData *appData = usrData;

    BeginDrawing();
    ClearBackground(RAYWHITE);

    switch (status) {
        case sys_EStatus_OnUpdate:
            app_fnDrawGui(appData);
            break;
        default:
            break;
    }
    EndDrawing();
}