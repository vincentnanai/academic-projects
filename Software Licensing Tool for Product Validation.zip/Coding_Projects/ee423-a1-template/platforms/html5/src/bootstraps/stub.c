// #include <raylib.h>
// #include <libwmdjs.h>
#include "stub.h"
#include <emscripten/emscripten.h>
#include <emscripten/websocket.h>
#include <libwmdjs.h>
#include <stdio.h>
#include <string.h>

typedef struct SApi TApi;
typedef struct {
  sys_TApiSetup vTable; // must be the first field
  void *appData;
  char *appTitleStr;
  bool isReady;
  sys_EStatus appStatus;
} TApiSetup;

typedef struct {
  sys_TApiWebSocket vTable; // must be the first field
  ws_TFnOnMsg onMsg;
  ws_TFnOnClosing onClosing;
  EMSCRIPTEN_WEBSOCKET_T jsObjWsHandle;
  bool isActive;
  TApi *root;
} TApiWebSocket;

typedef struct {
  sys_TApiCamera vTable; // must be the first field
  int camTarget;
  bool isActive;
  TApi *root;
} TApiCamera;

struct SApi {
  TApiSetup setup; // must be the first field
  TApiWebSocket webSocket;
  TApiCamera camera;
};

// Event handllers
static EM_BOOL apiWebSocket_fnOnOpen(int eventType,
                                     const EmscriptenWebSocketOpenEvent *e,
                                     void *userData) {
  TApi *api = userData;
  api->webSocket.isActive = true;
  return EM_TRUE;
}

static EM_BOOL apiWebSocket_fnOnError(int eventType,
                                      const EmscriptenWebSocketErrorEvent *e,
                                      void *userData) {
  TApi *api = userData;
  api->webSocket.onMsg(true, NULL, api->setup.appData);
  return EM_TRUE;
}

static EM_BOOL apiWebSocket_fnOnClose(int eventType,
                                      const EmscriptenWebSocketCloseEvent *e,
                                      void *userData) {
  TApi *api = userData;
  api->webSocket.onClosing(e->wasClean, e->code, e->reason, api->setup.appData);
  return EM_TRUE;
}

static EM_BOOL apiWebSocket_fnOnMessage(
    int eventType, const EmscriptenWebSocketMessageEvent *e, void *userData) {
  TApi *api = userData;
  ws_TMsg newMsg = {
      .header = {
          .type = e->isText ? ws_EMsgType_Text : ws_EMsgType_Binary,
          .size = e->numBytes,
      }};

  memcpy(newMsg.bytes, e->data, sizeof(newMsg.bytes));
  api->webSocket.onMsg(false, &newMsg, api->setup.appData);
  return EM_TRUE;
}

static sys_TApiCamera *apiSetup_useCamera(sys_TApiSetup *me) {
  TApi *api = (void *)me;
  if (!api->camera.root) {
    api->camera.root = api;
  }
  return &api->camera.vTable;
}

static void apiSetup_fnDefaultWsOnClosing(int wasClean, int code,
                                          const char *reason, void *appData) {
  emscripten_console_logf(
      "apiWebSocket [On Closing]: wasClean:%d, code:%d, reason:%s\n", wasClean,
      code, reason);
}

static sys_TApiWebSocket *apiSetup_useWebSocket(sys_TApiSetup *me,
                                                ws_TFnOnMsg fnOnMsg,
                                                ws_TFnOnClosing fnOnClosing) {
  TApi *api = (void*)me;

  if (!api->webSocket.root) {
    if (!emscripten_websocket_is_supported()) {
      emscripten_console_error(
          "WebSockets are not supported in this browser\n");
      return NULL;
    }

    if (!fnOnMsg) {
      emscripten_console_error(
          "apiSetup_useWebSocket: fnOnMsg can't be null\n");
      return NULL;
    }

    EmscriptenWebSocketCreateAttributes ws_attrs = {APP_URL, APP_WS_NAME,
                                                    EM_TRUE};
    api->webSocket.jsObjWsHandle = emscripten_websocket_new(&ws_attrs);
    api->webSocket.onClosing =
        fnOnClosing ? fnOnClosing : apiSetup_fnDefaultWsOnClosing;
    api->webSocket.onMsg = fnOnMsg;

#define WS_OnEvent(eventName, fnName)                                          \
  emscripten_websocket_set_on##eventName##_callback(                           \
      api->webSocket.jsObjWsHandle, api, fnName)
    WS_OnEvent(open, apiWebSocket_fnOnOpen);
    WS_OnEvent(error, apiWebSocket_fnOnError);
    WS_OnEvent(close, apiWebSocket_fnOnClose);
    WS_OnEvent(message, apiWebSocket_fnOnMessage);
#undef WS_OnEvent

    api->webSocket.root = api;
  }
  return &api->webSocket.vTable;
}

static api_ECall apiSetup_setAppData(sys_TApiSetup *me, void *appData) {
  TApi *api = (void*)me;
  api->setup.appData = appData;
  return api_ECall_Success;
}

static api_ECall apiSetup_setAppTitle(sys_TApiSetup *me, char *titleStr) {
  TApi *api = (void*)me;
  api->setup.appTitleStr = titleStr;
  return api_ECall_Success;
}

static bool apiWebSocket_fnIsApiActive(sys_TApiWebSocket *me) {
  TApiWebSocket *api = (void*)me;
  return api->isActive;
}

static api_ECall apiWebSocket_fnClose(sys_TApiWebSocket *me, unsigned short code,
                               const char *reason) {
  TApiWebSocket *api = (void*)me;
  if(!api->isActive) return api_ECall_ErrConnectionNotReady;
  if(emscripten_websocket_close(api->jsObjWsHandle,code,reason))
  {
    return api_ECall_Err;
  }
  return api_ECall_Success;
}

static api_ECall apiWebSocket_fnSend(sys_TApiWebSocket *me, ws_TMsg *msg) {
  TApiWebSocket *api = (void*)me;
  if(!api->isActive) return api_ECall_ErrConnectionNotReady;
  switch(msg->header.type) {
    case ws_EMsgType_Binary:
    if(emscripten_websocket_send_binary(api->jsObjWsHandle,msg->bytes,msg->header.size))
    {
      return api_ECall_Err;
    }
    break;
    case ws_EMsgType_Text:
    if(emscripten_websocket_send_utf8_text(api->jsObjWsHandle,msg->bytes))
    {
      return api_ECall_Err;
    }
    break;
  }
  return api_ECall_Success;
}

static bool apiCamera_fnIsApiActive(sys_TApiCamera *me) {
  TApiCamera *api = (void*)me;
  return api->isActive;
}

static api_ECall apiCamera_fnDrawByGLTextureId(sys_TApiCamera *me, int GLTextureId) {
  TApiCamera *api = (void*)me;
  if(!api->isActive) return api_ECall_ErrWebSocketNotReady;
  return wmd_drawTargetToTexture(api->camTarget,GLTextureId) ? api_ECall_Err : api_ECall_Success;
}

static int32_t apiCamera_fnGetWidth(sys_TApiCamera *me) {
  TApiCamera *api = (void*)me;
  if(!api->isActive) return 0;
  return wmd_getTargetCapsInt64(api->camTarget,wmd_ETargetCap_VideoWidthInt);
}

static int32_t apiCamera_fnGetHeight(sys_TApiCamera *me) {
  TApiCamera *api = (void*)me;
  if(!api->isActive) return 0;
  return wmd_getTargetCapsInt64(api->camTarget,wmd_ETargetCap_VideoHeightInt);
}

static TApi gApi = {
    // api vtable settings
    .setup = {
      .vTable = {
        .useCamera = apiSetup_useCamera,
        .useWebSocket = apiSetup_useWebSocket,
        .setAppData = apiSetup_setAppData,
        .setAppWindowTitle = apiSetup_setAppTitle,
      }
    },
    .webSocket = {
      .vTable = {
        .isApiActive = apiWebSocket_fnIsApiActive,
        .close = apiWebSocket_fnClose,
        .send = apiWebSocket_fnSend,
      }
    },
    .camera = {
      .vTable = {
        .isApiActive = apiCamera_fnIsApiActive,
        .drawByGLTextureId = apiCamera_fnDrawByGLTextureId,
        .getHeight = apiCamera_fnGetHeight,
        .getWidth = apiCamera_fnGetWidth,
      },
      .camTarget = -1
    }
  };

static void EventLoopUpdate(void);
int main() {
  emscripten_set_main_loop(EventLoopUpdate, 0, 1);
  return 0;
}

//----------------------------------------------------------------------------------
// Module Functions Definition
//----------------------------------------------------------------------------------

static void EventLoopUpdate(void) {
  if(!gApi.setup.isReady)
  {
    app_OnSetup(&gApi.setup.vTable);
    gApi.setup.isReady = true;
    SetConfigFlags(FLAG_WINDOW_RESIZABLE);
    InitWindow(50, 50, gApi.setup.appTitleStr);
  } 
  else
  {
    
    switch(gApi.setup.appStatus)
    {
      case sys_EStatus_OnInitWebsocket:
        if(!gApi.webSocket.root) {
          gApi.setup.appStatus++;
        } else if(gApi.webSocket.isActive) {
          app_OnUpdate(gApi.setup.appStatus, gApi.setup.appData);
          gApi.setup.appStatus++;
        }
        break;
      case sys_EStatus_OnInitCamera:
        if(!gApi.camera.root) {
          gApi.setup.appStatus++;
        } else if(gApi.camera.isActive) {
          app_OnUpdate(gApi.setup.appStatus, gApi.setup.appData);
          gApi.setup.appStatus++;
        } else {
          switch(wmd_status()) {
            case wmd_EStatus_Ready:
              {
                if(gApi.camera.camTarget < 0) {
                  int camId = wmd_getDefaultDeviceIdByType(wmd_EDeviceType_VideoInput);
                  gApi.camera.camTarget = wmd_createTarget();
                  wmd_bindTargetToDevice(gApi.camera.camTarget, camId);
                  printf("camId:%d,  targetId:%d\n", camId, gApi.camera.camTarget);
                } 
                else
                {
                  
                  gApi.camera.isActive = wmd_isTargetActive(gApi.camera.camTarget);
                }
              }
              return;
            case wmd_EStatus_PlatformNotSupported:
              gApi.setup.appStatus++;
            case wmd_EStatus_Initialising:
              return;
          }
        }
        break;
      
      case sys_EStatus_OnInitApp:
        app_OnUpdate(gApi.setup.appStatus, gApi.setup.appData);
        gApi.setup.appStatus = sys_EStatus_OnUpdate;
        break;
        
      default:
        app_OnUpdate(gApi.setup.appStatus, gApi.setup.appData);
    }
  }
}
