#pragma once
#include "../../../../src/config.h"
#include "../../../../src/msgStruct.h"
#include <stdint.h>
#include <raylib.h>


typedef enum {
  sys_EStatus_OnInitWebsocket,
  sys_EStatus_OnInitCamera,
  sys_EStatus_OnInitApp,
  sys_EStatus_OnUpdate,
  sys_EStatus_OnException,
  sys_EStatus_OnClosing,
} sys_EStatus;

typedef enum {
  api_ECall_WarnNoNewMsgs = 1,
  api_ECall_Success = 0,
  api_ECall_Err = -1,
  api_ECall_ErrWebSocketNotReady = -2,
  api_ECall_ErrConnectionClosed = -3,
  api_ECall_ErrConnectionNotReady = -4,
} api_ECall;

typedef void (*ws_TFnOnMsg) (bool isError, ws_TMsg* msg, void* appData);
typedef void (*ws_TFnOnClosing) (int wasClean, int code, const char *reason, void* appData);
typedef struct sys_SApiWebSocket sys_TApiWebSocket;
struct sys_SApiWebSocket {
  bool (*isApiActive) (sys_TApiWebSocket *me);
  api_ECall (*close) (sys_TApiWebSocket *me, unsigned short code, const char *reason);
  api_ECall (*send) (sys_TApiWebSocket *me, ws_TMsg* msg);
};

typedef struct sys_SApiCamera sys_TApiCamera;
struct sys_SApiCamera {
  bool (*isApiActive) (sys_TApiCamera *me);
  int32_t (*getHeight) (sys_TApiCamera *me);
  int32_t (*getWidth) (sys_TApiCamera *me);
  api_ECall (*drawByGLTextureId) (sys_TApiCamera *me, int GLTextureId);
};

typedef struct sys_SApiSetup sys_TApiSetup;
struct sys_SApiSetup {
  sys_TApiWebSocket* (*useWebSocket) (sys_TApiSetup *me, ws_TFnOnMsg, ws_TFnOnClosing);
  sys_TApiCamera* (*useCamera) (sys_TApiSetup *me);
  api_ECall (*setAppData) (sys_TApiSetup *me, void* appData);
  api_ECall (*setAppWindowTitle) (sys_TApiSetup *me, char* titleStr);
};

// Api Setup functions
void app_OnSetup(sys_TApiSetup *apiSetup);
void app_OnUpdate(sys_EStatus status, void *appData);

