#pragma once

#define APP_URL "ws://localhost:8080"
#define APP_WS_NAME "wsService"

typedef struct
{
  int i32;
  float f32;
  char data[4];
} app_TNetworkData;
