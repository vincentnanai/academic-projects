#pragma once
#include <stdint.h>

#define WS_TMSG_MAX_BYTES ((256) - sizeof(ws_TMsgHeader))

typedef enum : int8_t {
  ws_EMsgType_Text = 0,
  ws_EMsgType_Binary = 1,
} ws_EMsgType;

#define WS_MSG_BLANK(dtype) ((ws_TMsg){.header={.type = ws_EMsgType_##dtype}})

typedef struct {
  ws_EMsgType type;
  uint8_t size;
} ws_TMsgHeader;

typedef struct {
  ws_TMsgHeader header;
  char bytes[WS_TMSG_MAX_BYTES];
} ws_TMsg;

