
#include "lib_protocol.h"
#include <sodium.h>

static uint64_t xorshift128plus(uint64_t *s) {
  uint64_t s1 = s[0];
  const uint64_t s0 = s[1];
  s[0] = s0;
  s1 ^= s1 << 23;
  s[1] = s1 ^ s0 ^ (s1 >> 18) ^ (s0 >> 5);
  return s[1] + s0;
}


void protocol_fnLibInit()
{
    sodium_init();
}

void proto_fnGuidInit(protocol_TGuid* guid)
{
  randombytes_buf(guid->state.bytes, sizeof(guid->state.bytes));
}

void proto_fnGuidNext(protocol_TGuid* guid)
{
  guid->result.values[0] = xorshift128plus(guid->state.values);
  guid->result.values[1] = xorshift128plus(guid->state.values);
}

void proto_fnGuidToStr(protocol_TGuid* guid, protocol_TGuidStr dst)
{
  static const char *gHexSymbols = "0123456789ABCDEF";
  static const char *gTemplate = PROTOCOL_TGUID_STR_TEMPLATE;
  const char *p = gTemplate;
  
  for(int i=0, n; *p; p++, dst++)
  {
    n = guid->result.bytes[i >> 1];
    n = (i & 1) ? (n >> 4) : (n & 0xf);
    switch (*p) {
      case 'x'  : *dst = gHexSymbols[n];              i++;  break;
      case 'y'  : *dst = gHexSymbols[(n & 0x3) + 8];  i++;  break;
      default   : *dst = *p;
    }
  }
  *dst = '\0';
}


