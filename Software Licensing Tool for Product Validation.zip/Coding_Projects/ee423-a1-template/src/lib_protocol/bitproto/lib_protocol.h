// template.h.in
#pragma once

#include "protocol_bp.h"


// other useful tools
#include "lib_protocol_ext.h"
