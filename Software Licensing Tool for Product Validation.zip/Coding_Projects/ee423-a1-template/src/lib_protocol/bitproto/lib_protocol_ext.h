#pragma once

#include <stdint.h>
#include <sodium.h>

#define PROTOCOL_TGUID_STR_TEMPLATE "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx"

typedef char protocol_TGuidStr[sizeof(PROTOCOL_TGUID_STR_TEMPLATE)];
typedef struct protocol_SGuid protocol_TGuid;
struct protocol_SGuid
{
  union {
    char bytes[sizeof(uint64_t)*2];
    uint64_t values[2];
  } result;
  
  union {
    char bytes[sizeof(uint64_t)*2];
    uint64_t values[2];
  } state;
};

void protocol_fnLibInit();
void protocol_fnGuidInit(protocol_TGuid* guid);
void protocol_fnGuidNext(protocol_TGuid* guid);
