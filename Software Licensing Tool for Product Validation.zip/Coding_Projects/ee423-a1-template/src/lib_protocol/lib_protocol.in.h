// template.h.in
#pragma once

@generated_cIncludes@

// other useful tools
#include "lib_protocol_ext.h"