#ifndef STC_ALGORITHM_H_INCLUDED
#define STC_ALGORITHM_H_INCLUDED

#include "algo/crange.h"
#include "algo/filter.h"
#include "algo/utility.h"

#endif // STC_ALGORITHM_H_INCLUDED
