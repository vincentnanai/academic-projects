// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cdeq_
#include "deq.h"
