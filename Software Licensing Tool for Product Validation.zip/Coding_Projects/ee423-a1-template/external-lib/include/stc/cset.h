// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cset_
#define _i_isset
#include "hmap.h"
