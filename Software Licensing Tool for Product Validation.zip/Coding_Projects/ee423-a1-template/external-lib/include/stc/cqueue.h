// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cqueue_
#include "queue.h"
