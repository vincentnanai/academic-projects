// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cstack_
#include "stack.h"
