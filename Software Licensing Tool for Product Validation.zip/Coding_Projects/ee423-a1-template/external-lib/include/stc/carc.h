// THIS HEADER FILE IS DEPRECATED
#define _i_prefix carc_
#include "arc.h"
