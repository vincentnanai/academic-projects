// THIS HEADER FILE IS DEPRECATED
#define _i_prefix csset_
#define _i_isset
#include "smap.h"
