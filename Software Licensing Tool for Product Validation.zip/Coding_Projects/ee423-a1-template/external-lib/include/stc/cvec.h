// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cvec_
#include "vec.h"
