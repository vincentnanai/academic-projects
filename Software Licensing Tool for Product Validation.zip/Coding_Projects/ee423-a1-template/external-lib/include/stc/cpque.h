// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cpque_
#include "pque.h"
