// THIS HEADER FILE IS DEPRECATED
#define _i_prefix cmap_
#include "hmap.h"
